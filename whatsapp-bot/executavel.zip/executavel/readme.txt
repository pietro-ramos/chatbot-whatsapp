Guia Rápido para Usar o Bot do WhatsApp
Olá! Para usar o nosso bot de WhatsApp, siga estas instruções:

Você precisa do Google Chrome instalado no seu computador.

O Chrome precisa estar na pasta certa.
Isso significa que o Chrome precisa estar instalado no seguinte local:

C:\Program Files\Google\Chrome\Application\chrome.exe

Se o Chrome não estiver nesse local, o bot não vai funcionar.

O que fazer se o Chrome não estiver no local certo?

Passo 1: Abra o Chrome.
Passo 2: Vá até o menu no canto superior direito (onde tem três pontinhos).
Passo 3: Clique em "Ajuda" > "Sobre o Google Chrome".
Passo 4: Verifique onde o Chrome está instalado no seu computador (normalmente, o Chrome se instala automaticamente na pasta mencionada acima).
Passo 5: Se o Chrome não estiver na pasta certa, você pode reinstalar o Chrome ou mover a pasta para o local correto.
Depois que o Chrome estiver instalado no lugar certo, basta rodar o bot!
Clique duas vezes no arquivo do bot (whatsapp-bot.exe) e tudo estará pronto para funcionar!